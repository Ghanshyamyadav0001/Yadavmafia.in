/*
 * YADAVMAFIA.IN — Main functionality
 * Beginner note: change STORE.whatsapp/email/upi below before launch.
 */
const STORE = {
  name: "Yadavmafia.in",
  whatsapp: "919999999999", // Replace with your WhatsApp number, country code included.
  email: "support@yadavmafia.in", // Replace with your real support email.
  upi: "yadavmafia@upi" // Replace with your real UPI ID.
};

const money = n => `₹${Number(n).toLocaleString("en-IN")}`;

function getCart() {
  try { return JSON.parse(localStorage.getItem("yadavmafia_cart")) || []; }
  catch { return []; }
}
function saveCart(cart) {
  localStorage.setItem("yadavmafia_cart", JSON.stringify(cart));
  updateCartCount();
}
function cartCount() { return getCart().reduce((s, i) => s + i.qty, 0); }
function updateCartCount() {
  document.querySelectorAll("[data-cart-count]").forEach(el => el.textContent = cartCount());
}
function addToCart(id, qty = 1) {
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if (item) item.qty += qty;
  else cart.push({ id, qty });
  saveCart(cart);
  showToast("Added to cart");
}
function removeFromCart(id) { saveCart(getCart().filter(i => i.id !== id)); renderCart(); }
function setQty(id, qty) {
  qty = Math.max(1, Number(qty) || 1);
  saveCart(getCart().map(i => i.id === id ? {...i, qty} : i));
  renderCart();
}
function productById(id) { return PRODUCTS.find(p => p.id === Number(id)); }

function showToast(message) {
  let t = document.querySelector(".toast");
  if (!t) {
    t = document.createElement("div");
    t.className = "toast";
    document.body.appendChild(t);
  }
  t.textContent = message;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 1800);
}

function productCard(p) {
  return `
    <article class="book-card">
      <a class="book-cover" href="product.html?id=${p.id}" aria-label="View ${p.title}">
        <img src="${p.image}" alt="${p.title} eBook cover">
        ${p.badge ? `<span class="badge">${p.badge}</span>` : ""}
      </a>
      <div class="book-card-body">
        <div class="eyebrow">${p.category}</div>
        <h3><a href="product.html?id=${p.id}">${p.title}</a></h3>
        <p class="author">By ${p.author}</p>
        <div class="rating">★ ${p.rating} <span>(${p.reviews})</span></div>
        <div class="price-row"><strong>${money(p.price)}</strong><del>${money(p.compareAt)}</del></div>
        <button class="btn btn-gold full" onclick="addToCart(${p.id})">Add to cart</button>
      </div>
    </article>`;
}

function renderProductGrids() {
  document.querySelectorAll("[data-products]").forEach(el => {
    const limit = Number(el.dataset.limit || 99);
    el.innerHTML = PRODUCTS.slice(0, limit).map(productCard).join("");
  });
}

function renderProductDetail() {
  const mount = document.querySelector("[data-product-detail]");
  if (!mount) return;
  const id = new URLSearchParams(location.search).get("id");
  const p = productById(id) || PRODUCTS[0];
  document.title = `${p.title} | Yadavmafia.in`;
  mount.innerHTML = `
    <div class="detail-media"><img src="${p.image}" alt="${p.title} eBook cover"></div>
    <div class="detail-copy">
      <div class="eyebrow">${p.category}</div>
      <h1>${p.title}</h1>
      <p class="author">By ${p.author}</p>
      <div class="rating">★ ${p.rating} <span>${p.reviews} verified-style reviews</span></div>
      <div class="detail-price"><strong>${money(p.price)}</strong><del>${money(p.compareAt)}</del><span>${Math.round((1-p.price/p.compareAt)*100)}% OFF</span></div>
      <p class="lead">${p.description}</p>
      <ul class="check-list">${p.bullets.map(x => `<li>✓ ${x}</li>`).join("")}</ul>
      <div class="purchase-row">
        <button class="btn btn-gold" onclick="addToCart(${p.id})">Add to cart</button>
        <a class="btn btn-outline" href="cart.html">View cart</a>
      </div>
      <div class="micro-trust"><span>Instant digital delivery</span><span>Secure checkout</span><span>7-day promise</span></div>
    </div>`;
  const related = document.querySelector("[data-related]");
  if (related) related.innerHTML = PRODUCTS.filter(x => x.id !== p.id).slice(0,3).map(productCard).join("");
}

function renderCart() {
  const mount = document.querySelector("[data-cart]");
  if (!mount) return;
  const cart = getCart();
  if (!cart.length) {
    mount.innerHTML = `<div class="empty-state"><div class="empty-icon">◇</div><h2>Your cart is empty</h2><p>Pick a book and start your next chapter.</p><a class="btn btn-gold" href="shop.html">Explore books</a></div>`;
    document.querySelectorAll("[data-cart-total]").forEach(e => e.textContent = money(0));
    return;
  }
  let subtotal = 0;
  mount.innerHTML = cart.map(item => {
    const p = productById(item.id); if (!p) return "";
    subtotal += p.price * item.qty;
    return `<div class="cart-item">
      <img src="${p.image}" alt="${p.title} eBook cover">
      <div class="cart-item-info"><div class="eyebrow">${p.category}</div><h3>${p.title}</h3><p>${money(p.price)} each</p></div>
      <div class="qty"><button onclick="setQty(${p.id}, ${item.qty-1})" ${item.qty===1?"disabled":""}>−</button><span>${item.qty}</span><button onclick="setQty(${p.id}, ${item.qty+1})">+</button></div>
      <strong>${money(p.price*item.qty)}</strong>
      <button class="icon-btn" aria-label="Remove ${p.title}" onclick="removeFromCart(${p.id})">×</button>
    </div>`;
  }).join("");
  document.querySelectorAll("[data-cart-total]").forEach(e => e.textContent = money(subtotal));
}

function setupShop() {
  const grid = document.querySelector("[data-shop-grid]");
  if (!grid) return;
  const search = document.querySelector("[data-search]");
  const category = document.querySelector("[data-category]");
  const render = () => {
    const q = (search?.value || "").toLowerCase();
    const c = category?.value || "all";
    const list = PRODUCTS.filter(p => (c==="all" || p.category===c) && `${p.title} ${p.author}`.toLowerCase().includes(q));
    grid.innerHTML = list.length ? list.map(productCard).join("") : `<div class="empty-state compact"><h2>No books found</h2><p>Try another search.</p></div>`;
  };
  [...new Set(PRODUCTS.map(p=>p.category))].forEach(c => category?.insertAdjacentHTML("beforeend", `<option>${c}</option>`));
  search?.addEventListener("input", render); category?.addEventListener("change", render); render();
}

function setupMenu() {
  const btn = document.querySelector("[data-menu]");
  const nav = document.querySelector("[data-nav]");
  btn?.addEventListener("click", () => {
    nav.classList.toggle("open");
    btn.setAttribute("aria-expanded", nav.classList.contains("open"));
  });
}

function setupCheckout() {
  const form = document.querySelector("#checkout-form");
  if (!form) return;
  const upi = document.querySelector("[data-upi]");
  if (upi) upi.textContent = STORE.upi;
  form.addEventListener("submit", e => {
    e.preventDefault();
    const data = new FormData(form);
    const cart = getCart();
    if (!cart.length) return showToast("Your cart is empty");
    const lines = cart.map(i => {
      const p = productById(i.id); return `${p.title} x ${i.qty} = ${money(p.price*i.qty)}`;
    });
    const total = cart.reduce((s,i) => s + productById(i.id).price*i.qty, 0);
    const message = `New Yadavmafia.in order%0A%0AName: ${encodeURIComponent(data.get("name"))}%0APhone: ${encodeURIComponent(data.get("phone"))}%0AEmail: ${encodeURIComponent(data.get("email"))}%0A%0A${encodeURIComponent(lines.join("\n"))}%0A%0ATotal: ${encodeURIComponent(money(total))}`;
    window.open(`https://wa.me/${STORE.whatsapp}?text=${message}`, "_blank", "noopener");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartCount(); setupMenu(); renderProductGrids(); renderProductDetail(); renderCart(); setupShop(); setupCheckout();
  document.querySelectorAll("[data-email]").forEach(a => { a.textContent = STORE.email; a.href = `mailto:${STORE.email}`; });
  document.querySelectorAll("[data-upi]").forEach(e => e.textContent = STORE.upi);
});
