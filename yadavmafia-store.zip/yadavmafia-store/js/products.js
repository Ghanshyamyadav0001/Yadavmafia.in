/*
 * YADAVMAFIA.IN — Product catalog
 * Edit this array to add/change books.
 * image: path to the cover image.
 */
const PRODUCTS = [
  {
    id: 1,
    title: "Peace, Power & Money",
    author: "Yadavmafia",
    category: "Mindset",
    price: 999,
    compareAt: 1499,
    rating: 4.9,
    reviews: 128,
    badge: "Bestseller",
    image: "images/book-peace-power-money.svg",
    description: "A practical self-help guide for building a calmer mind, stronger discipline and a smarter relationship with money.",
    bullets: ["Mindset reset", "Discipline systems", "Money habits", "Action-focused exercises"]
  },
  {
    id: 2,
    title: "Think Like a Billionaire",
    author: "Yadavmafia",
    category: "Wealth",
    price: 899,
    compareAt: 1299,
    rating: 4.8,
    reviews: 96,
    badge: "Popular",
    image: "images/book-think-like-billionaire.svg",
    description: "A strategic mindset playbook focused on long-term thinking, leverage, decisions and wealth-building principles.",
    bullets: ["Long-term thinking", "Decision making", "Leverage", "Wealth principles"]
  },
  {
    id: 3,
    title: "The Discipline Code",
    author: "Yadavmafia",
    category: "Discipline",
    price: 799,
    compareAt: 1199,
    rating: 4.8,
    reviews: 74,
    badge: "New",
    image: "images/book-discipline-code.svg",
    description: "Turn motivation into repeatable systems with simple routines designed for consistency.",
    bullets: ["Daily systems", "Habit design", "Focus", "Consistency"]
  },
  {
    id: 4,
    title: "The Millionaire Mindset",
    author: "Yadavmafia",
    category: "Money",
    price: 749,
    compareAt: 1099,
    rating: 4.7,
    reviews: 63,
    badge: "Featured",
    image: "images/book-millionaire-mindset.svg",
    description: "Learn practical principles for thinking clearly about earning, saving, investing and personal growth.",
    bullets: ["Money mindset", "Income thinking", "Saving principles", "Growth plan"]
  },
  {
    id: 5,
    title: "Read. Grow. Dominate.",
    author: "Yadavmafia",
    category: "Growth",
    price: 699,
    compareAt: 999,
    rating: 4.9,
    reviews: 51,
    badge: "Editor's Pick",
    image: "images/book-read-grow-dominate.svg",
    description: "A compact personal-growth manual for turning knowledge into measurable action.",
    bullets: ["Personal growth", "Execution", "Confidence", "Weekly challenges"]
  }
];

window.PRODUCTS = PRODUCTS;
