# PROJECT BRIEF

## Business
- Store: Yadavmafia.in
- Business: Self-help / self-improvement e-books
- Target customer: General / mixed audience
- Market: India + international customers
- Launch inventory: 5–10 e-books
- Pricing: Premium positioning; individual prices can go up to about ₹1,000

## Brand
- Brand personality: Premium, classy, dark, cinematic, mafia/noir-inspired
- Visual direction: Black + gold
- Hero/background: client-provided image
- Typography: premium serif display + clean sans-serif body

## Pages
- Home
- Shop
- Product detail (dynamic via product.html?id=...)
- Cart
- Checkout
- About
- Contact
- Supporting FAQ / trust / legal sections as appropriate

## Payments
- Intended payment gateway: online payment gateway supporting UPI/cards
- Static prototype includes UPI section with editable placeholder UPI ID and QR
- Orders can be sent through WhatsApp from checkout; replace the placeholder WhatsApp number before launch

## Customer Contact
- Email only for customer support
- Email placeholder is editable in js/main.js

## Features
- Mobile-first, optimized for 375px
- Hamburger menu
- Working localStorage cart
- Quantity update / remove / totals
- Search and category filters
- Wishlist-style visual affordance
- Related books
- Offers / reviews / FAQ / trust messaging
- Sticky WhatsApp button
- SEO metadata and Open Graph tags on every page
- Descriptive image alt text
- Google Fonts
- Smooth transitions and subtle hover effects

## Product Artwork
- Covers are placeholders for now and can be replaced in js/products.js or images/

## Technical
- Plain HTML, CSS and vanilla JavaScript only
- No React, npm, build tools or framework
- Opens directly from index.html
- Suitable for static hosting such as GitHub Pages + a free static host
